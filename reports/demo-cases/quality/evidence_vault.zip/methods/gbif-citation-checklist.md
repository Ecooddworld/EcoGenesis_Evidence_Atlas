---
type: "method"
topic: "gbif_citation_checklist"
---
# GBIF Citation Checklist

This evidence pack does not include a GBIF download DOI. For publication, create and cite a DOI-backed GBIF occurrence download or derived dataset. Fixture or fallback packs are demo artifacts, not publication evidence.

## Checklist

- [x] datasetKey provenance preserved: Keep datasetKey in every record, aggregate and derived export.
- [x] contribution counts generated: Use dataset_contributions.csv to show records per contributing dataset.
- [x] license fields retained: Review missing or unknown licenses before formal publication.
- [ ] GBIF download DOI or derived dataset attached: Create a DOI-backed GBIF occurrence download or derived dataset and attach it to the report.
- [x] methods text generated: Review plain-English and journal-ready methods blocks before submission.

## Methods Text

Occurrence evidence for Lynx pardinus in Iberian Peninsula live bbox was assembled from GBIF-mediated occurrence-style records using bbox [-10.0, 35.0, 4.5, 44.5]. The workflow retained datasetKey provenance, record counts per contributing dataset, coordinate uncertainty, event dates, licenses and GBIF issue flags. The evidence readiness score was computed for purpose 'dataset_quality_review' from spatial, temporal, taxonomic, sampling and provenance components. Empty grid cells were treated as no-evidence cells rather than absences.

## Journal Methods Text

GBIF-mediated occurrence-style records for Lynx pardinus were queried for Iberian Peninsula live bbox using bounding box [-10.0, 35.0, 4.5, 44.5]. Records were retained with datasetKey-level provenance, contribution counts, coordinate uncertainty, event dates, licenses and issue flags. The EcoGenesis Evidence Passport computed a purpose-aware readiness score for dataset_quality_review; empty grid cells were interpreted as no-evidence cells and not as absences.
