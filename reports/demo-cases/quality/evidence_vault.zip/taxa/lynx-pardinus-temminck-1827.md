---
type: "taxon"
title: "Lynx pardinus (Temminck, 1827)"
taxonKey: 2435261
match_confidence: 100
---
# Lynx pardinus (Temminck, 1827)

## Links

- [Current run](../runs/51e12c0fb76d42f9ad818be4af84857f.md)

## Notes

- Accepted name: Lynx pardinus (Temminck, 1827)
