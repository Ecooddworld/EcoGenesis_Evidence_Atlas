---
type: "claim"
status: "requires_verification"
---
# Claim: Treat undersampled occupied cells as survey priorities, not confirmed absences.

Status: **requires_verification**
Current run: [run](../runs/51e12c0fb76d42f9ad818be4af84857f.md)

This claim is stored as graph memory so future runs can reuse or challenge it.
