---
type: "claim"
status: "supported"
---
# Claim: GBIF-mediated records matching the selected taxon and region are present in the evidence pack.

Status: **supported**
Current run: [run](../runs/51e12c0fb76d42f9ad818be4af84857f.md)

This claim is stored as graph memory so future runs can reuse or challenge it.
