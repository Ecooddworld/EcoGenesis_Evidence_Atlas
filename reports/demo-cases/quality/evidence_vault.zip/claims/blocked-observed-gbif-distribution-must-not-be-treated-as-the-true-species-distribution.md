---
type: "claim"
status: "blocked"
---
# Claim: Observed GBIF distribution must not be treated as the true species distribution.

Status: **blocked**
Current run: [run](../runs/51e12c0fb76d42f9ad818be4af84857f.md)

This claim is stored as graph memory so future runs can reuse or challenge it.
