---
type: "action"
---
# Action: Prioritize survey design around no-evidence and under-sampled grid cells.

Current run: [run](../runs/51e12c0fb76d42f9ad818be4af84857f.md)

Use this action as a review or follow-up task for the evidence workflow.
