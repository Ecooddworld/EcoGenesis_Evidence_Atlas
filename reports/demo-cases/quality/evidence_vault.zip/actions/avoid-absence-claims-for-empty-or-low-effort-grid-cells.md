---
type: "action"
---
# Action: Avoid absence claims for empty or low-effort grid cells.

Current run: [run](../runs/51e12c0fb76d42f9ad818be4af84857f.md)

Use this action as a review or follow-up task for the evidence workflow.
