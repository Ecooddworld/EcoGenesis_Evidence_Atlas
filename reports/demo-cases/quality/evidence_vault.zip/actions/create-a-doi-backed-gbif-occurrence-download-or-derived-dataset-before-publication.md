---
type: "action"
---
# Action: Create a DOI-backed GBIF occurrence download or derived dataset before publication.

Current run: [run](../runs/51e12c0fb76d42f9ad818be4af84857f.md)

Use this action as a review or follow-up task for the evidence workflow.
