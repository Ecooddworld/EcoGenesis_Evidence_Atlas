---
type: "issue"
issue: "High coordinate uncertainty"
affected_datasets: 1
---
# Issue: High coordinate uncertainty

Current run: [run](../runs/51e12c0fb76d42f9ad818be4af84857f.md)

## Affected Datasets

- [50c9509d-22c7-4a22-a47d-8c48425ef4a7](../datasets/50c9509d-22c7-4a22-a47d-8c48425ef4a7.md): 222 records, medium severity
