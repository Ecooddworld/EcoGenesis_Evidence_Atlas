---
type: "purpose"
title: "Invasive watch"
purpose: "invasive_watch"
score: 97.7
---
# Invasive watch

## Links

- [Current run](../runs/ca871495e66e482d9013a39ace873dcc.md)

## Notes

- High readiness: evidence is strong for the selected purpose, with remaining caveats documented.
