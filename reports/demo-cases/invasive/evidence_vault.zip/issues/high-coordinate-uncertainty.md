---
type: "issue"
issue: "High coordinate uncertainty"
affected_datasets: 1
---
# Issue: High coordinate uncertainty

Current run: [run](../runs/ca871495e66e482d9013a39ace873dcc.md)

## Affected Datasets

- [50c9509d-22c7-4a22-a47d-8c48425ef4a7](../datasets/50c9509d-22c7-4a22-a47d-8c48425ef4a7.md): 21 records, medium severity
