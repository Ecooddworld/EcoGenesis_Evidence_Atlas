---
type: "taxon"
title: "Aedes albopictus (Skuse, 1894)"
taxonKey: 1651430
match_confidence: 100
---
# Aedes albopictus (Skuse, 1894)

## Links

- [Current run](../runs/ca871495e66e482d9013a39ace873dcc.md)

## Notes

- Accepted name: Aedes albopictus (Skuse, 1894)
