---
type: "action"
---
# Action: Avoid absence claims for empty or low-effort grid cells.

Current run: [run](../runs/ca871495e66e482d9013a39ace873dcc.md)

Use this action as a review or follow-up task for the evidence workflow.
