---
type: "action"
---
# Action: Prioritize survey design around no-evidence and under-sampled grid cells.

Current run: [run](../runs/ca871495e66e482d9013a39ace873dcc.md)

Use this action as a review or follow-up task for the evidence workflow.
