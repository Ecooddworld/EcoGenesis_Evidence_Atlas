---
type: "claim"
status: "requires_verification"
---
# Claim: Inspect high coordinate-uncertainty records before using them in fine-scale decisions.

Status: **requires_verification**
Current run: [run](../runs/ca871495e66e482d9013a39ace873dcc.md)

This claim is stored as graph memory so future runs can reuse or challenge it.
