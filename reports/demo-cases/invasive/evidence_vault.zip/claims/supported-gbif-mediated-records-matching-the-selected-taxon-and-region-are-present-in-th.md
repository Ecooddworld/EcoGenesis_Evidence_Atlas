---
type: "claim"
status: "supported"
---
# Claim: GBIF-mediated records matching the selected taxon and region are present in the evidence pack.

Status: **supported**
Current run: [run](../runs/ca871495e66e482d9013a39ace873dcc.md)

This claim is stored as graph memory so future runs can reuse or challenge it.
