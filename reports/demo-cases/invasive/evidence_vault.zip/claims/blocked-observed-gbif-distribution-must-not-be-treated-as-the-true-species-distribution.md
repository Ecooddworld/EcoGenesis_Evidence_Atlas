---
type: "claim"
status: "blocked"
---
# Claim: Observed GBIF distribution must not be treated as the true species distribution.

Status: **blocked**
Current run: [run](../runs/ca871495e66e482d9013a39ace873dcc.md)

This claim is stored as graph memory so future runs can reuse or challenge it.
