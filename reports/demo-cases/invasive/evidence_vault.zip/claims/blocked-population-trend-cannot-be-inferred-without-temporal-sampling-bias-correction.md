---
type: "claim"
status: "blocked"
---
# Claim: Population trend cannot be inferred without temporal sampling-bias correction.

Status: **blocked**
Current run: [run](../runs/ca871495e66e482d9013a39ace873dcc.md)

This claim is stored as graph memory so future runs can reuse or challenge it.
