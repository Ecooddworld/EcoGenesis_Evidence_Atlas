---
type: "claim"
status: "requires_verification"
---
# Claim: Treat undersampled occupied cells as survey priorities, not confirmed absences.

Status: **requires_verification**
Current run: [run](../runs/ca871495e66e482d9013a39ace873dcc.md)

This claim is stored as graph memory so future runs can reuse or challenge it.
