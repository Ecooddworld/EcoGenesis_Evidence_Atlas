---
type: "vault_index"
run_id: "ca871495e66e482d9013a39ace873dcc"
taxon: "Aedes albopictus"
region: "Spain live GBIF bbox"
purpose: "invasive_watch"
---
# EcoGenesis Evidence Vault

This vault is a human-readable memory layer for the Evidence Passport.

## Core Links

- Run: [ca871495e66e482d9013a39ace873dcc](runs/ca871495e66e482d9013a39ace873dcc.md)
- Taxon: [Aedes albopictus (Skuse, 1894)](taxa/aedes-albopictus-skuse-1894.md)
- Region: [Spain live GBIF bbox](regions/spain-live-gbif-bbox.md)
- Purpose: [Invasive watch](purposes/invasive_watch.md)

## Graph Summary

- runs: 1
- taxa: 1
- regions: 1
- datasets: 8
- issues: 1
- claims: 10
- actions: 6
- artifacts: 8

## Review Files

- `../passport.html`
- `../decision_memo.md`
- `../submission_readiness.md`
- `../validation_summary.md`
- `../citations.md`
- `../publisher_feedback.md`
- `../run.json`
