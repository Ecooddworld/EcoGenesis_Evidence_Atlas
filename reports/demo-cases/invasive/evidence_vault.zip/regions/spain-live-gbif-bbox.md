---
type: "region"
title: "Spain live GBIF bbox"
bbox: [-10.0, 35.0, 4.5, 44.5]
---
# Spain live GBIF bbox

## Links

- [Current run](../runs/ca871495e66e482d9013a39ace873dcc.md)

## Notes

- BBox: `[-10.0, 35.0, 4.5, 44.5]`
