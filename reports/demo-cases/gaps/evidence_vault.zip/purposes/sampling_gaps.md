---
type: "purpose"
title: "Sampling gap analysis"
purpose: "sampling_gaps"
score: 82.56
---
# Sampling gap analysis

## Links

- [Current run](../runs/3a809b00d7944721a9364dcb5b3d0459.md)

## Notes

- High readiness: evidence is strong for the selected purpose, with remaining caveats documented.
