---
type: "claim"
status: "requires_verification"
---
# Claim: Inspect high coordinate-uncertainty records before using them in fine-scale decisions.

Status: **requires_verification**
Current run: [run](../runs/3a809b00d7944721a9364dcb5b3d0459.md)

This claim is stored as graph memory so future runs can reuse or challenge it.
