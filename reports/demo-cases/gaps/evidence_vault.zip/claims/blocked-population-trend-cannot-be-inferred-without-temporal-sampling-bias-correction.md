---
type: "claim"
status: "blocked"
---
# Claim: Population trend cannot be inferred without temporal sampling-bias correction.

Status: **blocked**
Current run: [run](../runs/3a809b00d7944721a9364dcb5b3d0459.md)

This claim is stored as graph memory so future runs can reuse or challenge it.
