---
type: "claim"
status: "blocked"
---
# Claim: Observed GBIF distribution must not be treated as the true species distribution.

Status: **blocked**
Current run: [run](../runs/3a809b00d7944721a9364dcb5b3d0459.md)

This claim is stored as graph memory so future runs can reuse or challenge it.
