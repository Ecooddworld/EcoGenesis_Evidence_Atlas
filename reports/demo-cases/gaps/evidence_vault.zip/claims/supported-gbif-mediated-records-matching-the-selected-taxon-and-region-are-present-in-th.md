---
type: "claim"
status: "supported"
---
# Claim: GBIF-mediated records matching the selected taxon and region are present in the evidence pack.

Status: **supported**
Current run: [run](../runs/3a809b00d7944721a9364dcb5b3d0459.md)

This claim is stored as graph memory so future runs can reuse or challenge it.
