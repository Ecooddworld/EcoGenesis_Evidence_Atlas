---
type: "taxon"
title: "Quercus robur L."
taxonKey: 2878688
match_confidence: 100
---
# Quercus robur L.

## Links

- [Current run](../runs/3a809b00d7944721a9364dcb5b3d0459.md)

## Notes

- Accepted name: Quercus robur L.
