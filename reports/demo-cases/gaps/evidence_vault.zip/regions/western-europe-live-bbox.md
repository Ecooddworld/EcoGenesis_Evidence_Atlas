---
type: "region"
title: "Western Europe live bbox"
bbox: [-10.0, 42.0, 12.0, 56.0]
---
# Western Europe live bbox

## Links

- [Current run](../runs/3a809b00d7944721a9364dcb5b3d0459.md)

## Notes

- BBox: `[-10.0, 42.0, 12.0, 56.0]`
