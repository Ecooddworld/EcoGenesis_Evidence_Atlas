---
type: "vault_index"
run_id: "3a809b00d7944721a9364dcb5b3d0459"
taxon: "Quercus robur"
region: "Western Europe live bbox"
purpose: "sampling_gaps"
---
# EcoGenesis Evidence Vault

This vault is a human-readable memory layer for the Evidence Passport.

## Core Links

- Run: [3a809b00d7944721a9364dcb5b3d0459](runs/3a809b00d7944721a9364dcb5b3d0459.md)
- Taxon: [Quercus robur L.](taxa/quercus-robur-l.md)
- Region: [Western Europe live bbox](regions/western-europe-live-bbox.md)
- Purpose: [Sampling gap analysis](purposes/sampling_gaps.md)

## Graph Summary

- runs: 1
- taxa: 1
- regions: 1
- datasets: 7
- issues: 0
- claims: 11
- actions: 4
- artifacts: 8

## Review Files

- `../passport.html`
- `../decision_memo.md`
- `../submission_readiness.md`
- `../validation_summary.md`
- `../citations.md`
- `../publisher_feedback.md`
- `../run.json`
