---
type: "action"
---
# Action: Avoid absence claims for empty or low-effort grid cells.

Current run: [run](../runs/3a809b00d7944721a9364dcb5b3d0459.md)

Use this action as a review or follow-up task for the evidence workflow.
