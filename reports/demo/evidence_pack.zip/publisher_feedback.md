# Publisher Feedback Pack

| datasetKey | Records affected | Main issue | Suggested fix |
| --- | ---: | --- | --- |
| 50c9509d-22c7-4a22-a47d-8c48425ef4a7 | 20 | High coordinate uncertainty | Improve georeferencing or flag coarse records for coarse-scale use only. |
