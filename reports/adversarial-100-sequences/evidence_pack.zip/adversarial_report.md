# GSEG/GSIG Adversarial Guardrail Report

Run ID: `ea9e5b6147734b919ec53070bedffeaa`

- Current run hard-gate failures: `0`
- Current run blocked or downgraded top species hits: `80`
- Frozen 100-record adversarial report: `reports/adversarial-100-sequences/adversarial_100_sequence_report.md`

The evidence pack treats the frozen adversarial suite as the release-level stress report and this run as the local invariant check. Species-level export remains fail-closed when any molecular, marker, assay or publication gate fails.
